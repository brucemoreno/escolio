README_COMECE_AQUI — ECOSSISTEMA VAQUITA v1.0-RC — PÓS-9.G

1. Use primeiro a pasta 00_COMECE_AQUI.
2. Para instalar o ecossistema, consulte 00_ATIVOS_POS_9G/02_INSTAL_USO_VAQ_ECO_v1RC_POS9G_FINAL.txt.
3. Para compreender a arquitetura completa, consulte 00_ATIVOS_POS_9G/01_KIT_MESTRE_VAQ_ECO_v1RC_POS9G_FINAL.txt.
4. Para migrar ou retomar desenvolvimento em novo chat, consulte 00_ATIVOS_POS_9G/03_MIGRACAO_VAQ_ECO_v1RC_POS9G_FINAL.txt.
5. Os prompts operacionais vigentes devem ficar em 01_PROMPTS_OPERACIONAIS_VIGENTES.
6. Arquivos em 03_HISTORICO_AUDITORIA e 99_VERSOES_ANTERIORES_NAO_USAR não devem ser usados como vigentes.
7. A FASE 9.G está tecnicamente aprovada.
8. Este kit ainda não declara versão v1.0 final.

AVISO DE INTEGRIDADE DO KIT

Os três documentos-mãe pós-9.G foram incluídos com nomes curtos canônicos.
Os prompts operacionais obrigatórios só são incluídos quando os arquivos existem no ambiente no momento da geração.
Nesta geração, os prompts operacionais obrigatórios ausentes estão listados em 01_PROMPTS_OPERACIONAIS_VIGENTES/PROMPTS_OPERACIONAIS_OBRIGATORIOS_NAO_INCLUIDOS.txt.
Não inventar, reconstruir ou substituir prompts operacionais por memória.
